<template>
  <div>
    <p class="home-welcome">欢迎访问社区管理系统！</p>
  </div>
</template>

<style scoped>
  .home-welcome{
    text-align: center;
    font-size: 22px;
    font-weight: bold;
  }
</style>
