<template>
  <div class="footer">
    <p id="company">中国电信股份有限公司上海分公司</p>
    <p id="num">“扫黄打非”举报专区 | 京ICP备 12007914号</p>
  </div>
</template>

<script type="text/ecmascript-6">
</script>

<style scoped>
#company, #num{
  font-size: 13px;
  font-weight: normal;
}

#company{
  float: left;
}

#num{
  float: right;
}

</style>
