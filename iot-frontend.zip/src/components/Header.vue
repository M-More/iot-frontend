<template>
  <div class="header">
    <div class="welcome">
      <div class="selection">
        <el-button icon="el-icon-s-unfold" class="foldbutton"></el-button>
      </div>

      <div class="welcome-name">
        <p class="welcome-name-content">欢迎登录：
          <el-select v-model="query" placeholder="请选择">
            <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
            </el-option>
          </el-select>
        </p>
      </div>

      <div class="personal-center">
        <p class="personal-center-content">个人中心：
          <el-select v-model="queryCenters" placeholder="请选择">
            <el-option
                v-for="item in optionsCenters"
                :key="item.value"
                :label="item.label"
                :value="item.value">
            </el-option>
          </el-select>
        </p>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data() {
      return {
        options: [{
          value: '选项1',
          label: "admin"
        }, {
          value: '选项2',
          label: 'user1'
        }, {
          value: '选项3',
          label: 'user2'
        }],
        optionsCenters: [{
          value: '01',
          label: "租户管理员"
        }, {
          value: '02',
          label: '普通管理员'
        }],
        query: '选项1',
        queryCenters: '01'
      }
    }
  }
</script>

<style scoped>
  .foldbutton{
    border: none;
  }

  .header{
  }

  .welcome{
    display: flex;

  }

  .selection{
    flex: 1;
  }

  .welcome-name{
    flex: 1;
    font-size: 15px;
  }

  .welcome-name-content{
    text-align: center;
  }


  .personal-center{
    flex: 1;
    font-size: 13px;
  }

  .personal-center-content{
    text-align: right;
  }

  .personal-center-content>>>.el-input__inner{
    border: 0;
    width: 120px;
  }
</style>
